# Goal 02 — Collect from the first sources

Status: not started

## Done when
- [ ] Supabase project set up with `organizations` and `raw_items` tables
- [ ] First 2–3 sources pull daily on a schedule, read-only
- [ ] Each item is linked to the right organization (≥90% on a 50-item spot check)
- [ ] Duplicates are skipped
- [ ] Each source documented in `docs/architecture.md` (endpoint, scope, how far back)

## Tasks
- [ ] Run `/data` on each source — look at 12–18 months before writing code
- [ ] Load watch list into `organizations`
- [ ] Build collector per source
- [ ] Spot-check 50 items by hand

## Notes
