# Goal 04 — Weekly list the team actually uses

Status: not started

## Done when
- [ ] Vercel app shows this week's opportunities, grouped by type, sorted by score
- [ ] Each card: organization, what happened, source link, why it matters, suggested action
- [ ] Useful / not useful buttons save to `feedback`
- [ ] Login limited to Almabase accounts
- [ ] Team used it 3 weeks in a row and acted on at least 3 items

## Tasks
- [ ] Run `/ui` — prototype in Claude Design first
- [ ] Build to match prototype
- [ ] Optional: Monday email/Slack digest linking to the list

## Notes
