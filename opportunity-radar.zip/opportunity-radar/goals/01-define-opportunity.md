# Goal 01 — Define what an opportunity is

Status: not started

## Done when
- [ ] 10+ real past opportunities written down (what we saw → what we did → outcome)
- [ ] 3 types defined with one example each: **brand**, **content**, **relationship**
- [ ] A 1–5 scoring rubric the team agrees with
- [ ] Watch list of organizations (start: customers + top prospects) exists as a table or CSV
- [ ] Decision logged on first 2–3 sources

## Tasks
- [ ] Run `/onboard`
- [ ] Pull past examples: webinars, BBCon/CASE sessions, e-book case studies, homecoming co-hosts
- [ ] Draft rubric → review with team
- [ ] Export watch list from HubSpot / CS Dashboard

## Notes
