# Goal 03 — Turn raw items into scored opportunities

Status: not started

## Done when
- [ ] Claude classifies each item: type, score 1–5, why, suggested action
- [ ] On the 10+ examples from Goal 01, the radar flags at least 8
- [ ] Fewer than 1 in 3 surfaced items are judged "not useful" in a weekly review
- [ ] Monthly Claude API cost known and under the agreed limit

## Tasks
- [ ] Write classify prompt using the rubric
- [ ] Back-test on past examples
- [ ] Tune with feedback

## Notes
