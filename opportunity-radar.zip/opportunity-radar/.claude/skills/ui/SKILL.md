---
name: ui
description: Design the radar's screens in Claude Design first, get approval, then build the Vercel app to match the approved prototype.
---

# UI — prototype, approve, then build

## Steps
1. Read `goals/04-weekly-list.md` and 10 real rows from the `signals` table (redacted).
2. Prototype in **Claude Design** using real examples, not lorem ipsum:
   - Weekly list: grouped by brand / content / relationship, sorted by score
   - Card: organization, what happened, source link, why it matters, suggested action, 👍 / 👎
   - Empty state ("Nothing new this week — sources last checked …")
   - Phone width
3. Share the prototype link. **Stop and wait for approval.** Log any choice in `docs/decisions.md`.
4. Build in the Next.js app to match the approved design — same layout, labels and order.
5. Screenshot the built page next to the prototype and list any differences.

## Rules
- Almabase brand colors and type if a design system exists; otherwise neutral.
- Every card must link to its source — no claims without a link.
- Works in light and dark mode.
