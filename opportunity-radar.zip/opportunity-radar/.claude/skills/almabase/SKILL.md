---
name: almabase
description: Almabase product and customer context for the radar - who customers are, how to read live data, and edge cases in matching organizations. Use whenever a task touches customers, prospects, or what counts as an opportunity.
---

# Almabase context

## The company
Almabase is an alumni engagement and advancement platform. Customers are mostly
**colleges, universities and independent schools**; the radar also watches
**nonprofits and healthcare** organizations (prospects and peers).

## What opportunities have looked like before
- **Content:** e-book case studies (*State of Year-Round Alumni Engagement*), data-backed blog posts
- **Brand / events:** co-presented sessions at BBCon, CASE District conferences, CASE DRIVE; webinars with client speakers (e.g. homecoming, giving days, migration from Blackbaud NetCommunity)
- **Relationship:** a customer's giving-day record, new advancement leader, campaign launch, award, milestone anniversary → congratulations, interview, or co-host invite

Signals worth catching: giving-day/challenge results, homecoming/reunion records, campaign launches or closes, leadership hires in advancement/alumni relations, awards (CASE Circle of Excellence), platform switches, conference speaking slots, press about alumni programs.

## Live data
- **CS Dashboard:** SQL via the MCP tool, schema `csm_dashboard`. Read-only. Customers are keyed by `site_id`.
- **HubSpot:** source of truth for prospects; match to customers by domain.

## Edge cases
- Same institution, many names ("Saint Mary's University of Minnesota" vs "Saint Mary's College") — match on domain, keep aliases.
- Systems with multiple campuses / foundations → one org row with a parent link.
- Former customers: still worth watching, flag status.
- News about a *different* org with the same name — require domain or location match before scoring above 2.
- Never surface anything private from a customer (ticket, email) as a public brand idea without CS sign-off — label internal-source signals clearly.
