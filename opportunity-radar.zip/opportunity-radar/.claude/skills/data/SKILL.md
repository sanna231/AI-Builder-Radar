---
name: data
description: Read 12-18 months of real data from a source (HubSpot, Intercom, Notion, Slack, Gmail, CS Dashboard, public web) strictly read-only, and report what's actually there before anything is designed or built.
---

# Data — look before building

## Rules (non-negotiable)
- **Read-only.** SELECT / GET only. No writes, updates, deletes, sends, or posts.
- Never print keys or full email/ticket bodies. Show counts, field names, and short redacted excerpts.
- Nothing raw is saved inside the repo. Scratch output goes to `data/` (git-ignored) or nowhere.

## Steps
1. Ask which source, unless obvious from context.
2. Pull 12–18 months. For each source report:
   - volume per month (is it 10 items or 10,000?)
   - fields available, and which link to an organization (domain, company id, site id)
   - 5 real, redacted examples that **would** have been an opportunity, and 5 that wouldn't
   - gaps: missing fields, messy names, duplicates, rate limits
3. Check against the watch list: what % of items can be matched to an organization?
4. Write findings:
   - source details → `docs/architecture.md`
   - surprises / choices → `docs/decisions.md`
   - blockers → `docs/pending.md`
5. Recommend: keep this source for v1, later, or drop — with one reason.

## Source hints
- **CS Dashboard:** SQL via the MCP tool, schema `csm_dashboard`.
- **HubSpot:** companies + notes + engagements; match on domain.
- **Slack:** only channels the bot is invited to.
- **Public web:** news + institution websites; LinkedIn has no open API.
