---
name: onboard
description: Run first in a new session or new project. Asks one open question, then fills the gaps in CLAUDE.md, goals/ and docs/pending.md from the answer.
---

# Onboard

Goal: get from "idea" to a filled-in project in one conversation, without a questionnaire.

## Steps
1. Read `CLAUDE.md`, `docs/pending.md`, and every file in `goals/`.
2. Ask **one** open question, and wait:
   > "Tell me about the last time you spotted a great opportunity from a customer or prospect — what did you see, where, and what did you do with it?"
3. From the answer, list what is still unknown against the "Open questions" in `docs/pending.md`.
4. Ask only the gaps that block Goal 01 — max 3 follow-ups, one at a time, multiple choice when possible.
5. Write the answers back:
   - who / what / sources → `CLAUDE.md`
   - examples and rubric drafts → `goals/01-define-opportunity.md` Notes
   - choices made → `docs/decisions.md` (what, why, what we gave up)
   - tick resolved items in `docs/pending.md`
6. End with: what's now known, what's still open, the next skill to run (usually `/data`).

## Rules
- Plain language. No jargon without a one-line explanation.
- Don't invent customers or examples. If unknown, leave it open.
