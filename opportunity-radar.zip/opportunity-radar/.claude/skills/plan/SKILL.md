---
name: plan
description: Produce the build plan as ONE self-contained HTML page from templates/plan-artifact.html, filled from CLAUDE.md, goals/ and docs/. Run after /onboard and /data.
---

# Plan — one page

## Steps
1. Read `CLAUDE.md`, all `goals/*.md`, and `docs/*.md`.
2. Copy `templates/plan-artifact.html` and replace every `{{PLACEHOLDER}}`:
   - `{{PROJECT}}`, `{{UPDATED}}`, `{{ONE_LINER}}`
   - `{{GOALS}}` — one `<article class="goal">` per goal file: title, status, Done-when list
   - `{{FLOW}}` — the source → collect → understand → show steps, from architecture.md
   - `{{DECISIONS}}` — newest 5 from decisions.md
   - `{{OPEN}}` — open items from pending.md
3. Publish it as an artifact (or save as `plan.html` if no artifact tool) so the team can open it.
4. Summarise in chat in 3 lines: current goal, next task, biggest risk.

## Rules
- Only what's written in the docs. If a section is empty, say "Not decided yet" — don't fill it in.
- Re-run whenever a goal changes status.
