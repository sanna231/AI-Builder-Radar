# Decisions

Format: date · decision · why · what we gave up. Newest at the top.

---

**2026-10-28 · Read-only on every source**
Why: the radar suggests; people act. Removes the risk of it emailing a customer or editing HubSpot.
Gave up: one-click actions (e.g. "create HubSpot task") — revisit after v1.

**2026-10-28 · Store links + short summaries for public web, not full articles**
Why: copyright, storage size, and the team only needs enough to decide.
Gave up: offline full-text search across articles.

**2026-10-28 · Weekly list first, alerts later**
Why: proves signal quality before anyone gets pinged. Feedback on the list tunes the prompt.
Gave up: real-time alerts for urgent items (e.g. a customer leadership change).

**2026-10-28 · Stack: GitHub + Supabase + Vercel + Claude API**
Why: program standard; one database, one host, scheduled functions built in.
Gave up: no-code tools (Zapier/Make) — faster to start, harder to tune and log.
