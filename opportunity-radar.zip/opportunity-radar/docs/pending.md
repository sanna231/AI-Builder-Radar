# Pending — whole-build items only

Goal-specific tasks live in `goals/`. This file is for things that cut across goals.

## Open questions (answer in `/onboard`)
- [ ] Which 2–3 sources first? (suggestion: HubSpot + Slack + public news)
- [ ] Who sees the weekly list besides Sannday? Is CS in v1?
- [ ] What counts as an "opportunity"? Need 10 real past examples to calibrate.
- [ ] Watch-list size: all customers, or a named list to start?
- [ ] Gmail: which inbox(es), and is that allowed by IT/security?

## Access to request
- [ ] HubSpot private app (read scopes: companies, notes, engagements)
- [ ] Intercom token (read conversations)
- [ ] Notion integration added to the right pages
- [ ] Slack bot invited to chosen channels
- [ ] Google OAuth for Gmail (read-only)
- [ ] Anthropic API key with a spend limit

## Risks
- Customer PII in emails/tickets → keep excerpts short, never in git, RLS on tables.
- LinkedIn has no open API → public web may be news + institution sites only.
- Noise → feedback loop must exist before adding more sources.
