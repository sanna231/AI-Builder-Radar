# Architecture — how data flows

Read this when something breaks. Each arrow is a place to check.

```
 SOURCES (read-only)            COLLECT                 UNDERSTAND              SHOW
 ───────────────────            ───────                 ──────────              ────
 HubSpot (companies, notes) ┐
 Intercom (conversations)   │
 Notion (account notes)     ├─► Supabase function ─► raw_items table ─► Claude API ─► signals table ─► Vercel app
 Slack (#customer channels) │   (scheduled, daily)    (dedupe by url/id)  classify +     (opportunity,   (weekly list,
 Gmail (shared inbox)       │                                              summarize      org, score,     useful / not
 CS Dashboard (metrics)     │                                                             reason)         useful)
 Public web (news, LinkedIn,┘                                                                                │
   institution websites)                                                                                     ▼
                                                                                              feedback table ─► tunes prompt
```

## Tables (Supabase)
| Table | One row = | Key columns |
|---|---|---|
| `organizations` | one customer / prospect / org we watch | name, segment (advancement / nonprofit / healthcare), status (customer / prospect / other), hubspot_id, site_id |
| `raw_items` | one thing collected from a source | source, source_id, url, org_id, captured_at, text_excerpt |
| `signals` | one item judged worth a human look | raw_item_id, type (brand / content / relationship), score 1–5, why, suggested_action |
| `feedback` | one human verdict | signal_id, useful (bool), note, user |

## Where to look when…
- **Nothing new this week** → check the scheduled function logs in Supabase, then each source token.
- **Wrong organization matched** → `organizations` aliases / domain matching.
- **Junk signals** → the classify prompt + recent `feedback` rows marked not useful.
- **App blank** → Vercel logs; Supabase anon key / row-level security.

## Fill in as built
- Source-by-source: endpoint, scope, rate limit, how far back.
