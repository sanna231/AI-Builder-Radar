# Opportunity Radar — master instructions

## What this is
An AI-powered radar that scans what customers, prospects and organizations in
**advancement, nonprofit and healthcare** are doing, and surfaces items that could
become a **brand, content, or relationship-building opportunity** for Almabase.
It replaces manual monitoring. Owner: Sannday (Brand Marketing). Not an engineer —
explain decisions in plain language and ask before anything irreversible.

## Who uses it
Brand marketing + customer success. They open a weekly list of opportunities,
mark each one useful / not useful, and act (pitch a webinar, a case study, a
conference co-presentation, a congratulations note).

## Stack
GitHub (code) · Supabase (Postgres + auth + scheduled functions) · Vercel (web app) ·
Claude API (classify + summarize) · source APIs (see `docs/architecture.md`).

## How to work here
1. New session? Read `docs/pending.md` and the active goal in `goals/` first.
2. One goal at a time. A goal is done only when every "Done when" line is true.
3. Record every non-obvious choice in `docs/decisions.md` (what, why, what we gave up).
4. Update progress in the goal file itself, not in chat.
5. Use real data (`/data` skill) before designing anything. Never invent sample customers.
6. Plain-language summary at the end of each session: what changed, what's next.

## Hard rules
- Never read, print or commit `.env` or any key. Key names live in `.env.example` only.
- Never run `supabase db push` or touch production data without explicit approval.
- Read-only access to every source system. The radar never sends emails, posts, or edits CRM records.
- Raw source data (emails, Slack messages, tickets) stays out of git — see `.gitignore`.
- Public-web content: store a link + short summary, not full copied articles.

## Skills (run in this order the first time)
`/onboard` → `/data` → `/plan` → `/ui` · `/almabase` anytime for product context.

## Map
- `docs/architecture.md` — how data flows, for debugging
- `docs/decisions.md` — decision log
- `docs/pending.md` — whole-build open items
- `goals/` — one file per goal, progress lives there
